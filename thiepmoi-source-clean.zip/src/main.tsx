import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';
import './editorial.css';
import './cover-editorial.css';
import './invitation-motion.css';

const rootElement = document.getElementById('root');

if (rootElement) {
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}
